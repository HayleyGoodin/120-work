# Hayley Goodin
### September 5, 2018
#### Week Two Response

##### 1.
This week I started learning how to use various different sources to start coding. I paid close attention to details and reasoning for every instruction and demonstration given.
##### 2.
The assignment started out difficult since I had no idea what a command line was or how to use it and am learning how to use new programs that I know nothing about.

##### 3.
I did not need to ask my fellow students for any help on the assignment. I used google for help. I had no issues following instructions after figuring out the command line.

##### 4.
Everything that has been covered this week has been something new that I learned, I knew nothing about this part of computers and still have a lot to learn.

##### 5.
I have yet to help out fellow classmates as I am also learning and not confident in my knowledge of this material just yet. I do not want to be a person that gives somebody else the wrong information leading them to failure in the course. However, I have given feedback and input about what I think.
