### Homework 9 Responses



#### 1
This week I learned how to create a list to better organize my code as well as loop through my list. I take things slow and don't try to kill myself with amounts of work. I like to take the time to mess around and test other things and actually learn how the new functions are working.

#### 2
Learning arrays was not at all difficult but figuring out where I want to use them was pretty experimental. My sketch is very simple but I think it clearly demonstrates how I learned the function and how to loop it.

#### 3
Just like I mentioned in the previous question, I went simple so that I could experiment with how arrays work. I used a mousePressed function to both navigate though my array and also change the color of the background to make it more interesting.

#### 4
My sketch started with my previous sketch of the balloon, but I just wanted to concentrate on the array and functions without a big code in my way.

#### 5
I haven't helped any classmates this week but I have got in contact with my actual assigned TA for future support.
